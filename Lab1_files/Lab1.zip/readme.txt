->Lab1.py is the python source code for these encryption and decryption algorithms.
->To run this code, create a file with anything that you want to test this encryption and decryption program.
->I used my test file Plain_text.txt which I will provide. I also have a file with a list of 8 different
keys, which I will also provide in the submission.
->This program will automatically run both the encryption and decryption algorithms and create seperate files
which will contain the encrypted and decrypted data.
->I created this program with Pycharm on Mac OSX so this program should work best with this software.