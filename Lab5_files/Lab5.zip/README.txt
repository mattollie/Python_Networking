-> Run the server program first and enter the IP address of the local computer
-> Next, run the client program and enter the same IP address for the host computer
-> Enter the name of the file that you want to transfer on the client side and the file will begin transferring to the host
-> Enter the name of the file that is to be received on the server side and then the server will have the contents of the file
-> The client programs will automatically disconnect the socket once the file has been transferred, but the server will
   continue to run. Press CTRL^Z to exit the server program.
-> Two test documents will be provided. 'test.txt' is larger document for testing the multiple of 1024 bytes while
   'sick.txt' is a smaller document.