-> The program names are self explanatory on which ones are the server and client programs for both tcp and udp.
-> In either case, the server program should be ran first and then any number of clients can connect to the server.
-> On the client side, enter the number of times the command will be executed, the time delay between command executions,
and the command. This information will be sent to the server and the it will return the contents of the executed
command.