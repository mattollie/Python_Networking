import socket

import os

# Get the port number from the user

port = input("Enter the port number: ")

# Get the IP address of the server

ip_address = input("Enter the server IP address: ")

# A tuple with server ip and port

serverAddress = (ip_address, int(port))

# Create a datagram socket

Socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)


# Socket is not in connected state yet...sendto() can be used


# Get the message from the user to send to the server

msg = input("Enter a message: ")

if msg == 'exit':
    Socket.sendto(msg.encode(), (ip_address, int(port)))
    Socket.close()
    print('Closing connection')
    exit()
# Encrypt message and send message to the server

with open('file.txt', 'wb') as message_file:
    message_file.write(bytes(msg, 'UTF-8'))

os.system('python3.7 /Users/Lakefork15/PycharmProjects/ECE_456_Labs/Lab1_files/Lab1_Encrypt.py')

with open('Encrypted_data', 'rb') as encrypted:
    encrypt_send = encrypted.read()
Socket.sendto(encrypt_send, (ip_address, int(port)))


# Read UDP server's response datagram

response = Socket.recvfrom(250)

print(response)

msg2 = input("Enter a message: ")

if msg2 == 'exit':
    Socket.sendto(msg2.encode(), (ip_address, int(port)))
    Socket.close()
    print('closing connection')
    exit()

with open('file.txt', 'wb') as message_file:
    message_file.write(bytes(msg2, 'UTF-8'))

os.system('python3.7 /Users/Lakefork15/PycharmProjects/ECE_456_Labs/Lab1_files/Lab1_Encrypt.py')

with open('Encrypted_data', 'rb') as encrypted:
    encrypt_send = encrypted.read()
Socket.sendto(encrypt_send, (ip_address, int(port)))

response = Socket.recvfrom(250)

print(response)

response2 = Socket.recvfrom(250)

print(response2)

msg3 = input("Enter a message: ")

if msg3 == 'exit':
    Socket.sendto(msg3.encode(), (ip_address, int(port)))
    Socket.close()
    print('Closing connection')
    exit()

with open('file.txt', 'wb') as message_file:
    message_file.write(bytes(msg3, 'UTF-8'))

os.system('python3.7 /Users/Lakefork15/PycharmProjects/ECE_456_Labs/Lab1_files/Lab1_Encrypt.py')

with open('Encrypted_data', 'rb') as encrypted:
    encrypt_send = encrypted.read()
Socket.sendto(encrypt_send, (ip_address, int(port)))

response = Socket.recvfrom(250)

print(response)

response2 = Socket.recvfrom(250)

print(response2)

response3 = Socket.recvfrom(250)

print(response3)

msg4 = input("Enter a message: ")

if msg4 == 'exit':
    Socket.sendto(msg4.encode(), (ip_address, int(port)))
    Socket.close()
    print('Closing connection')
    exit()

with open('file.txt', 'wb') as message_file:
    message_file.write(bytes(msg4, 'UTF-8'))

os.system('python3.7 /Users/Lakefork15/PycharmProjects/ECE_456_Labs/Lab1_files/Lab1_Encrypt.py')

with open('Encrypted_data', 'rb') as encrypted:
    encrypt_send = encrypted.read()
Socket.sendto(encrypt_send, (ip_address, int(port)))

response = Socket.recvfrom(250)

print(response)

response2 = Socket.recvfrom(250)

print(response2)

response3 = Socket.recvfrom(250)

print(response3)

response4 = Socket.recvfrom(250)

print(response4)

msg5 = input("Enter a message: ")

if msg5 == 'exit':
    Socket.sendto(msg5.encode(), (ip_address, int(port)))
    Socket.close()
    print('Closing connection')
    exit()

with open('file.txt', 'wb') as message_file:
    message_file.write(bytes(msg5, 'UTF-8'))

os.system('python3.7 /Users/Lakefork15/PycharmProjects/ECE_456_Labs/Lab1_files/Lab1_Encrypt.py')

with open('Encrypted_data', 'rb') as encrypted:
    encrypt_send = encrypted.read()
Socket.sendto(encrypt_send, (ip_address, int(port)))

response = Socket.recvfrom(250)

print(response)

response2 = Socket.recvfrom(250)

print(response2)

response3 = Socket.recvfrom(250)

print(response3)

response4 = Socket.recvfrom(250)

print(response4)

response5 = Socket.recvfrom(250)

print(response5)

msg6 = input("Enter a message: ")

if msg6 == 'exit':
    Socket.sendto(msg6.encode(), (ip_address, int(port)))
    Socket.close()
    print('Closing connection')
    exit()

with open('file.txt', 'wb') as message_file:
    message_file.write(bytes(msg6, 'UTF-8'))

os.system('python3.7 /Users/Lakefork15/PycharmProjects/ECE_456_Labs/Lab1_files/Lab1_Encrypt.py')

with open('Encrypted_data', 'rb') as encrypted:
    encrypt_send = encrypted.read()
Socket.sendto(encrypt_send, (ip_address, int(port)))

response = Socket.recvfrom(250)

print(response)

response2 = Socket.recvfrom(250)

print(response2)

response3 = Socket.recvfrom(250)

print(response3)

response4 = Socket.recvfrom(250)

print(response4)

response5 = Socket.recvfrom(250)

print(response5)

response6 = Socket.recvfrom(250)

print(response6)

