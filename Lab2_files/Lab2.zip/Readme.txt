-> Run the sender program first with six inputs. In order, the inputs should be, the input file, source IP address,
destination IP address, source port, destination port, and then "datagram.bin"
-> The sender program will will create the UDP packet, encrypt it, and then write it to "Encrypted_data."
-> Next run the Receiver program with three inputs. In order, the inputs should be, the source IP address, the
destination IP address, and then "datagram.bin".
-> The receiver program will decrypt the UDP packet, write it to "Decrypted_data", and output the original input file
to "Output_file."
-> I will also include the encryption and decryption programs along with the keys file necessary to run these programs.